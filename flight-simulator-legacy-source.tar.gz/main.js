/* Two-player game setup, combat rules, split rendering, HUD, and controls. */

(function startApplication() {
  const errorPanel = document.getElementById("loading-error");
  const errorText = document.getElementById("loading-error-text");
  if (typeof THREE === "undefined") {
    errorPanel.classList.remove("is-hidden");
    document.getElementById("start-screen").classList.add("is-hidden");
    return;
  }

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
  } catch (error) {
    errorText.textContent = "WebGL could not start. Enable hardware acceleration in Chromium and reload.";
    errorPanel.classList.remove("is-hidden");
    document.getElementById("start-screen").classList.add("is-hidden");
    return;
  }

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x89a9c1);
  scene.fog = new THREE.Fog(0x89a9c1, 260, 1050);
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.2));
  renderer.setScissorTest(true);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  document.getElementById("scene-container").appendChild(renderer.domElement);

  scene.add(new THREE.HemisphereLight(0xc8dded, 0x53614a, 1.7));
  const sunlight = new THREE.DirectionalLight(0xfff1d2, 2);
  sunlight.position.set(180, 260, 100);
  sunlight.castShadow = true;
  sunlight.shadow.mapSize.set(1024, 1024);
  sunlight.shadow.camera.left = -150;
  sunlight.shadow.camera.right = 150;
  sunlight.shadow.camera.top = 150;
  sunlight.shadow.camera.bottom = -150;
  scene.add(sunlight);
  const city = createCity(scene);
  const buildingColliders = city.userData.buildingColliders;

  const cameras = [
    new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 1500),
    new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 1500)
  ];

  function makeControls() {
    return { pitch: 0, roll: 0, yawRate: 0, fire: false };
  }

  const players = [1, 2].map((number, index) => ({
    number,
    camera: cameras[index],
    flight: new ArcadeFlight(scene, cameras[index], number),
    controls: makeControls(),
    remote: null,
    connection: "disconnected",
    health: 100,
    score: 0,
    respawnAt: 0,
    invulnerableUntil: 2,
    lastShotAt: -1
  }));

  const clock = new THREE.Clock();
  const keys = { ArrowUp: false, ArrowDown: false, ArrowLeft: false, ArrowRight: false, Space: false };
  const bullets = [];
  const bulletPool = [];
  const explosions = [];
  // Every player's bullets render in one draw call instead of one mesh each.
  const maxVisibleBullets = 96;
  const bulletPositionArrays = [new Float32Array(maxVisibleBullets * 3), new Float32Array(maxVisibleBullets * 3)];
  const bulletPointGeometries = bulletPositionArrays.map((positions) => {
    const geometry = new THREE.BufferGeometry();
    const attribute = new THREE.BufferAttribute(positions, 3);
    attribute.setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute("position", attribute);
    geometry.setDrawRange(0, 0);
    return geometry;
  });
  const bulletPoints = bulletPointGeometries.map((geometry, index) => {
    const points = new THREE.Points(
      geometry,
      new THREE.PointsMaterial({ color: index === 0 ? 0x55a7ff : 0xff5966, size: 2.1, sizeAttenuation: true })
    );
    scene.add(points);
    return points;
  });
  const explosionGeometry = new THREE.BoxGeometry(0.7, 0.7, 0.7);
  const explosionMaterials = [
    new THREE.MeshBasicMaterial({ color: 0x68b2ff, transparent: true }),
    new THREE.MeshBasicMaterial({ color: 0xff6672, transparent: true })
  ];

  let gameTime = 0;
  let hudTimer = 0;
  let toastTimer = null;
  let matchPaused = false;
  let rematchAt = 0;
  const winningScore = 5;

  const ui = {
    startScreen: document.getElementById("start-screen"),
    setupStatus: [document.getElementById("setup-status-1"), document.getElementById("setup-status-2")],
    remoteIP: [document.getElementById("remote-ip-1"), document.getElementById("remote-ip-2")],
    score: [document.getElementById("score-1"), document.getElementById("score-2")],
    health: [document.getElementById("health-number-1"), document.getElementById("health-number-2")],
    healthFill: [document.getElementById("health-fill-1"), document.getElementById("health-fill-2")],
    altitude: [document.getElementById("altitude-1"), document.getElementById("altitude-2")],
    speed: [document.getElementById("speed-1"), document.getElementById("speed-2")],
    pitch: [document.getElementById("pitch-1"), document.getElementById("pitch-2")],
    roll: [document.getElementById("roll-1"), document.getElementById("roll-2")],
    connection: [document.getElementById("connection-1"), document.getElementById("connection-2")],
    warning: [document.getElementById("warning-1"), document.getElementById("warning-2")],
    respawn: [document.getElementById("respawn-1"), document.getElementById("respawn-2")],
    hitMarker: [document.getElementById("hit-marker-1"), document.getElementById("hit-marker-2")],
    hud: [document.getElementById("hud-1"), document.getElementById("hud-2")],
    divider: document.getElementById("split-divider"),
    matchStatus: document.getElementById("match-status"),
    matchResult: document.getElementById("match-result"),
    winnerText: document.getElementById("winner-text"),
    rematchCountdown: document.getElementById("rematch-countdown"),
    networkDebug: document.getElementById("network-debug"),
    debug: [document.getElementById("debug-1"), document.getElementById("debug-2")],
    remoteLog: document.getElementById("remote-log"),
    remoteLogLines: document.getElementById("remote-log-lines"),
    remoteLogEmpty: document.getElementById("remote-log-empty"),
    logPause: document.getElementById("log-pause"),
    toast: document.getElementById("toast")
  };

  const remoteLogEntries = [];
  const maximumLogEntries = 160;
  let remoteLogPaused = false;

  const savedIPs = [
    localStorage.getItem("esp32RemoteIP1") || "",
    localStorage.getItem("esp32RemoteIP2") || ""
  ];
  ui.remoteIP.forEach((input, index) => { input.value = savedIPs[index]; });

  function createRemoteLogRow(entry) {
    const row = document.createElement("li");
    row.className = `remote-log__line remote-log__line--p${entry.player} remote-log__line--${entry.kind}`;
    const time = document.createElement("time");
    const player = document.createElement("b");
    const message = document.createElement("code");
    time.textContent = entry.time;
    player.textContent = `P${entry.player}`;
    message.textContent = entry.message;
    row.append(time, player, message);
    return row;
  }

  function renderRemoteLog() {
    ui.remoteLogLines.replaceChildren(...remoteLogEntries.map(createRemoteLogRow));
    ui.remoteLogEmpty.classList.toggle("is-hidden", remoteLogEntries.length > 0);
    ui.remoteLogLines.classList.toggle("is-hidden", remoteLogEntries.length === 0);
    ui.remoteLogLines.scrollTop = ui.remoteLogLines.scrollHeight;
  }

  function appendRemoteLog(playerIndex, event) {
    if (remoteLogPaused) return;
    const current = new Date();
    const time = `${current.toLocaleTimeString("en-GB", { hour12: false })}.${String(current.getMilliseconds()).padStart(3, "0")}`;
    const entry = {
      player: playerIndex + 1,
      kind: event.kind || "status",
      message: event.message || "unknown event",
      time
    };
    remoteLogEntries.push(entry);
    if (remoteLogEntries.length > maximumLogEntries) remoteLogEntries.shift();

    if (!ui.remoteLog.classList.contains("is-hidden")) {
      if (ui.remoteLogLines.children.length >= maximumLogEntries) {
        ui.remoteLogLines.firstElementChild?.remove();
      }
      ui.remoteLogLines.appendChild(createRemoteLogRow(entry));
      ui.remoteLogEmpty.classList.add("is-hidden");
      ui.remoteLogLines.classList.remove("is-hidden");
      ui.remoteLogLines.scrollTop = ui.remoteLogLines.scrollHeight;
    }
  }

  function toggleRemoteLog(forceOpen) {
    const shouldOpen = forceOpen ?? ui.remoteLog.classList.contains("is-hidden");
    ui.remoteLog.classList.toggle("is-hidden", !shouldOpen);
    if (shouldOpen) renderRemoteLog();
  }

  function validIPv4(address) {
    const parts = address.trim().split(".");
    return parts.length === 4 && parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255);
  }

  function connectPlayer(index) {
    const ip = savedIPs[index];
    if (!validIPv4(ip)) return;
    const player = players[index];
    player.remote = new MotionRemote(
      `ws://${ip}:81`,
      (state) => setConnection(index, state),
      (packet) => {
        player.controls.pitch = packet.pitch;
        // The physical MPU6050 mounting reports roll opposite to the aircraft.
        // Reverse it so right controller tilt produces a right bank and turn.
        player.controls.roll = -packet.roll;
        player.controls.yawRate = packet.yawRate;
      },
      (fire) => {
        player.controls.fire = fire.held;
        if (fire.newPress) fireBullet(index, true);
      },
      (message) => { if (message === "CALIBRATED") showToast(`Player ${index + 1} remote calibrated`); },
      (event) => appendRemoteLog(index, event)
    );
    player.remote.connect();
  }

  function setConnection(index, state) {
    const player = players[index];
    player.connection = state;
    const tag = ui.connection[index];
    tag.className = "connection-tag";
    if (state === "connected") {
      tag.classList.add("connection-tag--online");
      tag.querySelector("span").textContent = "Connected";
      ui.setupStatus[index].textContent = "Connected";
    } else if (state === "stale") {
      tag.classList.add("connection-tag--stale");
      tag.querySelector("span").textContent = "Signal stale";
      ui.setupStatus[index].textContent = "Signal stale";
      player.controls.fire = false;
    } else if (state === "connecting") {
      tag.classList.add("connection-tag--trying");
      tag.querySelector("span").textContent = "Connecting";
      ui.setupStatus[index].textContent = "Connecting";
    } else {
      tag.classList.add("connection-tag--offline");
      tag.querySelector("span").textContent = "Disconnected";
      ui.setupStatus[index].textContent = savedIPs[index] ? "Retrying" : "Not configured";
      Object.assign(player.controls, { pitch: 0, roll: 0, yawRate: 0, fire: false });
    }
    updateViewMode();
  }

  function playerIsPresent(player) {
    return player.connection === "connected" || player.connection === "stale";
  }

  function updateViewMode() {
    const split = players.every(playerIsPresent);
    document.body.classList.toggle("is-split", split);
    ui.divider.classList.toggle("is-hidden", !split);
    ui.hud[0].classList.toggle("is-hidden", !split && playerIsPresent(players[1]));
    ui.hud[1].classList.toggle("is-hidden", !split && !playerIsPresent(players[1]));
    // Split screen draws the scene twice, so use native 1x rendering on Pi.
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, split ? 1 : 1.2));
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function saveAndConnect() {
    const newIPs = ui.remoteIP.map((input) => input.value.trim());
    if (!validIPv4(newIPs[0]) && !validIPv4(newIPs[1])) {
      showToast("Enter at least one valid ESP32 IP address");
      return;
    }
    if (newIPs[0] && newIPs[0] === newIPs[1]) {
      showToast("Player 1 and Player 2 need different ESP32 IP addresses");
      return;
    }
    newIPs.forEach((ip, index) => {
      if (ip && !validIPv4(ip)) {
        showToast(`Player ${index + 1} IP address is not valid`);
        throw new Error("invalid-ip");
      }
      localStorage.setItem(`esp32RemoteIP${index + 1}`, ip);
    });
    showToast("Remote addresses saved — reconnecting");
    window.setTimeout(() => window.location.reload(), 500);
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    ui.toast.textContent = message;
    ui.toast.classList.remove("is-hidden");
    toastTimer = window.setTimeout(() => ui.toast.classList.add("is-hidden"), 2500);
  }

  function calibrate(index) {
    if (players[index].remote?.send("CALIBRATE")) showToast(`Calibration sent to Player ${index + 1}`);
    else showToast(`Player ${index + 1} remote is offline`);
  }

  function fireBullet(playerIndex, immediate = false) {
    const player = players[playerIndex];
    if (!player.flight.alive || matchPaused || gameTime < player.invulnerableUntil) return;
    // About 15 rounds per second gives the gun a clear, continuous stream.
    if (!immediate && gameTime - player.lastShotAt < 0.065) return;
    player.lastShotAt = gameTime;

    // Reuse projectile vectors so automatic fire does not create garbage every
    // frame on a Raspberry Pi.
    const bullet = bulletPool.pop() || {
      position: new THREE.Vector3(),
      direction: new THREE.Vector3()
    };
    bullet.direction.set(0, 0, -1).applyQuaternion(player.flight.airplane.quaternion).normalize();
    bullet.position.copy(player.flight.airplane.position).addScaledVector(bullet.direction, 6);
    bullet.owner = playerIndex;
    bullet.expiresAt = gameTime + 2.0;
    bullets.push(bullet);
  }

  function removeBullet(index) {
    const removed = bullets.splice(index, 1)[0];
    if (removed) bulletPool.push(removed);
  }

  function updateBulletVisuals() {
    const counts = [0, 0];
    bullets.forEach((bullet) => {
      const count = counts[bullet.owner];
      if (count >= maxVisibleBullets) return;
      const offset = count * 3;
      const positions = bulletPositionArrays[bullet.owner];
      positions[offset] = bullet.position.x;
      positions[offset + 1] = bullet.position.y;
      positions[offset + 2] = bullet.position.z;
      counts[bullet.owner]++;
    });
    bulletPointGeometries.forEach((geometry, index) => {
      geometry.setDrawRange(0, counts[index]);
      geometry.attributes.position.needsUpdate = true;
    });
  }

  function damagePlayer(targetIndex, attackerIndex) {
    const target = players[targetIndex];
    if (!target.flight.alive || gameTime < target.invulnerableUntil || matchPaused) return;
    target.health = Math.max(0, target.health - 20);
    showHitMarker(attackerIndex);
    if (target.health > 0) return;

    target.flight.setAlive(false);
    target.respawnAt = gameTime + 3;
    createExplosion(target.flight.airplane.position, targetIndex);
    players[attackerIndex].score += 1;

    if (players[attackerIndex].score >= winningScore) finishMatch(attackerIndex);
  }

  function crashPlayer(playerIndex) {
    const player = players[playerIndex];
    if (!player.flight.alive || matchPaused) return;
    player.health = 0;
    player.flight.setAlive(false);
    player.respawnAt = gameTime + 3;
    createExplosion(player.flight.airplane.position, playerIndex);
    ui.matchStatus.textContent = `Player ${playerIndex + 1} crashed`;
    window.setTimeout(() => {
      if (!matchPaused) ui.matchStatus.textContent = "Training match";
    }, 1500);
  }

  function checkBuildingCollisions() {
    players.forEach((player, playerIndex) => {
      if (!player.flight.alive) return;
      const position = player.flight.airplane.position;
      for (const box of buildingColliders) {
        if (position.x >= box.minX && position.x <= box.maxX &&
            position.y >= box.minY && position.y <= box.maxY &&
            position.z >= box.minZ && position.z <= box.maxZ) {
          crashPlayer(playerIndex);
          break;
        }
      }
    });
  }

  function showHitMarker(playerIndex) {
    const marker = ui.hitMarker[playerIndex];
    marker.classList.add("is-active");
    window.setTimeout(() => marker.classList.remove("is-active"), 130);
  }

  function createExplosion(position, playerIndex) {
    const pieces = [];
    for (let index = 0; index < 12; index++) {
      const mesh = new THREE.Mesh(explosionGeometry, explosionMaterials[playerIndex].clone());
      mesh.position.copy(position);
      mesh.userData.velocity = new THREE.Vector3(
        (Math.random() - 0.5) * 20,
        (Math.random() - 0.1) * 18,
        (Math.random() - 0.5) * 20
      );
      scene.add(mesh);
      pieces.push(mesh);
    }
    explosions.push({ pieces, expiresAt: gameTime + 1 });
  }

  function finishMatch(winnerIndex) {
    matchPaused = true;
    rematchAt = gameTime + 3;
    ui.winnerText.textContent = `Player ${winnerIndex + 1} wins`;
    ui.matchResult.classList.remove("is-hidden");
    ui.matchStatus.textContent = "Match complete";
  }

  function resetMatch() {
    clearProjectiles();
    players.forEach((player) => {
      player.score = 0;
      player.health = 100;
      player.respawnAt = 0;
      player.invulnerableUntil = gameTime + 2;
      player.flight.reset();
    });
    matchPaused = false;
    ui.matchResult.classList.add("is-hidden");
    ui.matchStatus.textContent = "Training match";
  }

  function clearProjectiles() {
    while (bullets.length) bulletPool.push(bullets.pop());
    updateBulletVisuals();
  }

  function updateCombat(deltaTime) {
    players.forEach((player, index) => { if (player.controls.fire) fireBullet(index); });

    for (let index = bullets.length - 1; index >= 0; index--) {
      const bullet = bullets[index];
      bullet.position.addScaledVector(bullet.direction, 260 * deltaTime);
      if (gameTime >= bullet.expiresAt) { removeBullet(index); continue; }
      const targetIndex = bullet.owner === 0 ? 1 : 0;
      const target = players[targetIndex];
      if (target.flight.alive && bullet.position.distanceToSquared(target.flight.airplane.position) < 30) {
        removeBullet(index);
        damagePlayer(targetIndex, bullet.owner);
      }
    }
    updateBulletVisuals();

    for (let index = explosions.length - 1; index >= 0; index--) {
      const explosion = explosions[index];
      const lifeLeft = Math.max(0, explosion.expiresAt - gameTime);
      explosion.pieces.forEach((piece) => {
        piece.position.addScaledVector(piece.userData.velocity, deltaTime);
        piece.material.opacity = lifeLeft;
        piece.rotation.x += deltaTime * 4;
      });
      if (lifeLeft <= 0) {
        explosion.pieces.forEach((piece) => { scene.remove(piece); piece.material.dispose(); });
        explosions.splice(index, 1);
      }
    }

    players.forEach((player) => {
      if (!player.flight.alive && !matchPaused && gameTime >= player.respawnAt) {
        player.health = 100;
        player.invulnerableUntil = gameTime + 2;
        player.flight.reset();
      }
      if (player.flight.alive && gameTime < player.invulnerableUntil) {
        player.flight.airplane.visible = Math.floor(gameTime * 10) % 2 === 0;
      } else if (player.flight.alive) {
        player.flight.airplane.visible = true;
      }
    });

    if (matchPaused) {
      const remaining = Math.max(0, Math.ceil(rematchAt - gameTime));
      ui.rematchCountdown.textContent = remaining;
      if (gameTime >= rematchAt) resetMatch();
    }
  }

  function normalizedControls(player, index) {
    let pitch = THREE.MathUtils.clamp(player.controls.pitch / 45, -1, 1);
    let roll = THREE.MathUtils.clamp(player.controls.roll / 45, -1, 1);
    let yawRate = player.controls.yawRate;

    // A stale stream returns toward neutral and cannot leave the gun stuck on.
    if (player.connection === "stale") {
      pitch = 0;
      roll = 0;
      yawRate = 0;
      player.controls.fire = false;
    }

    // Keyboard fallback controls Player 1 whenever its remote is unavailable.
    if (index === 0 && player.connection !== "connected" && player.connection !== "stale") {
      pitch = (keys.ArrowDown ? 1 : 0) - (keys.ArrowUp ? 1 : 0);
      roll = (keys.ArrowRight ? 1 : 0) - (keys.ArrowLeft ? 1 : 0);
      yawRate = 0;
      player.controls.fire = keys.Space;
    }
    if (Math.abs(pitch) < 0.025) pitch = 0;
    if (Math.abs(roll) < 0.025) roll = 0;
    return { pitch, roll, yawRate };
  }

  function updateFlights(deltaTime) {
    if (matchPaused) return;
    players.forEach((player, index) => {
      const input = normalizedControls(player, index);
      // The ESP32 and aircraft already provide light filtering. Applying a
      // third input filter here made steering visibly trail the controller.
      player.flight.update(deltaTime, input.pitch, input.roll, input.yawRate);
    });
  }

  function renderViews() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const split = players.every(playerIsPresent);

    if (split) {
      const half = Math.floor(width / 2);
      players.forEach((player, index) => {
        const viewportWidth = index === 0 ? half : width - half;
        const left = index === 0 ? 0 : half;
        player.camera.aspect = viewportWidth / height;
        player.camera.updateProjectionMatrix();
        renderer.setViewport(left, 0, viewportWidth, height);
        renderer.setScissor(left, 0, viewportWidth, height);
        renderer.render(scene, player.camera);
      });
    } else {
      const active = playerIsPresent(players[1]) ? players[1] : players[0];
      active.camera.aspect = width / height;
      active.camera.updateProjectionMatrix();
      renderer.setViewport(0, 0, width, height);
      renderer.setScissor(0, 0, width, height);
      renderer.render(scene, active.camera);
    }
  }

  function updateHUD() {
    players.forEach((player, index) => {
      ui.score[index].textContent = player.score;
      ui.health[index].textContent = player.health;
      ui.healthFill[index].style.transform = `scaleX(${player.health / 100})`;
      ui.altitude[index].textContent = String(Math.round(player.flight.airplane.position.y)).padStart(3, "0");
      ui.speed[index].textContent = String(Math.round(player.flight.flightSpeed)).padStart(3, "0");
      ui.pitch[index].textContent = player.controls.pitch.toFixed(1);
      ui.roll[index].textContent = player.controls.roll.toFixed(1);
      ui.warning[index].classList.toggle("is-hidden", !player.flight.isLowAltitude() || !player.flight.alive);

      const respawning = !player.flight.alive && !matchPaused;
      ui.respawn[index].classList.toggle("is-hidden", !respawning);
      if (respawning) ui.respawn[index].querySelector("strong span").textContent = String(Math.max(0, Math.ceil(player.respawnAt - gameTime))).padStart(2, "0");

      const network = player.remote?.getDiagnostics();
      const ping = network?.pingMs == null ? "--" : `${Math.round(network.pingMs)}ms`;
      const pps = network ? Math.round(network.packetsPerSecond) : 0;
      const age = network?.packetAgeMs == null ? "--" : `${Math.round(network.packetAgeMs)}ms`;
      const sequence = network?.sequence == null ? "--" : network.sequence;
      const fire = network?.fireHeld ? "ON" : "OFF";
      const status = (network?.status || "offline").toUpperCase();
      ui.debug[index].textContent = `${status} · PING ${ping} · ${pps} PPS · AGE ${age} · SEQ ${sequence} · FIRE ${fire}`;
    });
  }

  function animate() {
    requestAnimationFrame(animate);
    const deltaTime = Math.min(clock.getDelta(), 0.05);
    gameTime += deltaTime;
    updateFlights(deltaTime);
    checkBuildingCollisions();
    updateCombat(deltaTime);
    hudTimer += deltaTime;
    if (hudTimer >= 0.08) { hudTimer = 0; updateHUD(); }
    renderViews();
  }

  document.getElementById("connect-button").addEventListener("click", () => {
    try { saveAndConnect(); } catch (error) { if (error.message !== "invalid-ip") throw error; }
  });
  document.getElementById("start-button").addEventListener("click", () => ui.startScreen.classList.add("is-hidden"));
  document.getElementById("calibrate-1").addEventListener("click", () => calibrate(0));
  document.getElementById("calibrate-2").addEventListener("click", () => calibrate(1));
  document.getElementById("reset-button").addEventListener("click", resetMatch);
  document.getElementById("log-button").addEventListener("click", () => toggleRemoteLog());
  document.getElementById("log-close").addEventListener("click", () => toggleRemoteLog(false));
  document.getElementById("log-clear").addEventListener("click", () => {
    remoteLogEntries.length = 0;
    renderRemoteLog();
  });
  ui.logPause.addEventListener("click", () => {
    remoteLogPaused = !remoteLogPaused;
    ui.logPause.textContent = remoteLogPaused ? "Resume" : "Pause";
    showToast(remoteLogPaused ? "Remote log paused" : "Remote log resumed");
  });
  document.getElementById("log-copy").addEventListener("click", async () => {
    if (!remoteLogEntries.length) {
      showToast("Remote log is empty");
      return;
    }
    const text = remoteLogEntries
      .map((entry) => `${entry.time} P${entry.player} ${entry.message}`)
      .join("\n");
    try {
      await navigator.clipboard.writeText(text);
      showToast("Remote log copied");
    } catch (error) {
      showToast("Browser blocked copying; select the log manually");
    }
  });
  document.getElementById("fullscreen-button").addEventListener("click", async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch (error) { showToast("Fullscreen is not available in this browser"); }
  });

  window.addEventListener("keydown", (event) => {
    if (event.target.matches?.("input, textarea, [contenteditable='true']")) return;
    if (Object.prototype.hasOwnProperty.call(keys, event.code)) {
      keys[event.code] = true;
      event.preventDefault();
    } else if (Object.prototype.hasOwnProperty.call(keys, event.key)) {
      keys[event.key] = true;
      event.preventDefault();
    }
    if (event.code === "Space" && !event.repeat && !playerIsPresent(players[0])) {
      fireBullet(0, true);
    }
    if (event.key.toLowerCase() === "r") resetMatch();
    if (event.key.toLowerCase() === "d" && !event.repeat) {
      ui.networkDebug.classList.toggle("is-hidden");
    }
    if (event.key.toLowerCase() === "l" && !event.repeat) toggleRemoteLog();
  });
  window.addEventListener("keyup", (event) => {
    if (Object.prototype.hasOwnProperty.call(keys, event.code)) keys[event.code] = false;
    if (Object.prototype.hasOwnProperty.call(keys, event.key)) keys[event.key] = false;
  });
  window.addEventListener("blur", () => Object.keys(keys).forEach((key) => { keys[key] = false; }));
  window.addEventListener("resize", () => {
    const split = players.every(playerIsPresent);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, split ? 1 : 1.2));
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  savedIPs.forEach((ip, index) => { if (validIPv4(ip)) connectPlayer(index); });
  updateViewMode();
  updateHUD();
  animate();
})();
