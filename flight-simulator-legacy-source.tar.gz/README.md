# Wireless Motion Combat Flight Simulator

A beginner-friendly two-player Three.js flight simulator for a Raspberry Pi. Each aircraft is controlled by its own ESP32 + MPU6050 remote over WebSocket.

## Project files

```text
flight-simulator/
├── assets/
│   └── three.min.js
├── index.html
├── style.css
├── websocket.js
├── city.js
├── flight.js
├── main.js
├── PRODUCT.md
├── DESIGN.md
└── README.md
```

## Raspberry Pi setup

1. Install **Raspberry Pi OS with Desktop** using Raspberry Pi Imager.
2. Start the Pi, connect a keyboard and HDMI display, and open Terminal.
3. Copy the complete `flight-simulator` folder to the Pi. Three.js is already stored locally in `assets/three.min.js`, so the project does not need internet access.
4. In Terminal, open the project folder:

   ```bash
   cd flight-simulator
   ```

5. Start a local web server:

   ```bash
   python3 -m http.server 8080
   ```

6. Open Chromium and visit:

   ```text
   http://localhost:8080
   ```

Do not open `index.html` by double-clicking it. The local HTTP server gives the browser a reliable way to load all project files.

## ESP32 button wiring

| Purpose | ESP32 pin | Other button side |
|---|---:|---|
| Centre/calibrate | GPIO4 | GND |
| Fire machine gun | GPIO5 | GND |

Both pins use the ESP32's internal pull-up resistor. Avoid holding the GPIO5 fire button while resetting or powering on the ESP32 because GPIO5 is also a boot-strapping pin on common ESP32 boards.

## Connect the ESP32 remotes using DHCP

1. In `flight_remote.ino`, set `WIFI_SSID` and `WIFI_PASSWORD` to the router or phone hotspot you will use.
2. Connect the Raspberry Pi to that same Wi-Fi network.
3. Upload the same firmware to both ESP32 controllers. Power one at a time and note each controller's address.
4. Open Arduino Serial Monitor at 115200 baud and find lines similar to:

   ```text
   ESP32 IP address: 192.168.1.45
   WebSocket URL: ws://192.168.1.45:81
   ```

5. Open the simulator at `http://localhost:8080`.
6. Enter the first address under **Player 1** and the second address under **Player 2**, then press **Save & connect remotes**.

The router or hotspot assigns each ESP32 address automatically using DHCP. The addresses must be different. The simulator remembers both in Chromium. If DHCP assigns a different address later, enter the newly printed address again.

## Controls and combat rules

- Tilt forward: pitch down.
- Tilt backward: pitch up.
- Tilt left or right: bank and turn.
- GPIO4: save the current controller position as neutral.
- Hold GPIO5: fire the aircraft machine gun.
- **Reset match** or `R`: reset aircraft, health, and scores.
- `D`: show or hide live ping, packet-rate, packet-age, sequence, and fire diagnostics.
- `L`: open the sampled remote-data log. Use **Pause**, **Clear**, and **Copy** when troubleshooting.
- Arrow Up: pitch down.
- Arrow Down: pitch up.
- Arrow Left/Right: bank and turn.
- Spacebar: fire Player 1's gun when its remote is offline.

Each hit removes 20 health. Destroying the other aircraft awards one point. Touching a shop building crashes the aircraft but does not award the opponent a point. A destroyed or crashed aircraft respawns after three seconds and receives two seconds of spawn protection. The first player to five points wins; after a three-second result screen, scores reset and a new match begins automatically.

With one remote connected, its chase camera fills the display. When both remotes connect, the renderer automatically changes to a left/right split screen.

## Testing plan

### Test 1 — Simulator only

Start the local server with no remote connected. Confirm the arrow keys fly Player 1 and Spacebar fires. Press `R` and confirm the match resets.

### Test 2 — MPU6050

Open Arduino Serial Monitor at 115200 baud. Confirm the MPU6050 is detected and pitch, roll, and yaw-rate values change when the remote moves.

### Test 3 — Pi-to-ESP32 Wi-Fi

Connect both the Raspberry Pi and ESP32 to the same router or phone hotspot. Copy the DHCP address printed by the ESP32, then optionally run `ping ESP32_ADDRESS` in Terminal.

### Test 4 — WebSocket

Open the simulator and confirm the top-left status changes from **DISCONNECTED** to **CONNECTED**.

### Test 5 — Telemetry

Press `D`. Confirm the controller reports about 50–60 packets/second, packet age normally stays below 50 ms, and ping remains stable. Move the controller and confirm pitch and roll values change in the HUD.

Quickly tap GPIO5 about 20 times and confirm every tap produces a shot. Then hold it for two seconds and confirm the gun fires continuously at about 15 rounds/second.

### Test 6 — Two-player motion flight

Connect both remotes. Confirm the display changes to left/right split screen and each controller moves only its own airplane.

### Test 7 — Calibration

Hold the controller in a comfortable neutral position and press **CALIBRATE REMOTE**. Confirm the neutral point changes.

### Test 8 — Fullscreen

Press **FULLSCREEN** and confirm the canvas fills the HDMI display. Press `Esc` to leave fullscreen.

### Test 9 — Combat and rematch

Hold GPIO5 to fire. Confirm hits reduce health, destruction awards one point, respawn occurs after three seconds, and reaching five points starts a new match automatically.

## Troubleshooting

### WebSocket stays disconnected

- The `python3 -m http.server` Terminal shows only browser file requests such as `200` and `304`; it cannot see the direct browser-to-ESP32 WebSocket traffic. Press `L` in the simulator to inspect that traffic.
- Confirm the Pi and ESP32 are connected to the same Wi-Fi network.
- Copy the current DHCP address from Serial Monitor into the simulator IP field.
- Confirm Serial Monitor shows the WebSocket URL with port `81`.
- Open `http://localhost:8080`, not an HTTPS address. Browsers can block insecure `ws://` connections from secure `https://` pages.
- Keep using Player 1's arrow-key and Spacebar fallback while diagnosing the remote.

### ESP32 cannot join Wi-Fi

- Check `WIFI_SSID` and `WIFI_PASSWORD` in the firmware.
- ESP32 supports 2.4 GHz Wi-Fi; enable 2.4 GHz on the router/hotspot.
- Move the ESP32 closer and confirm it has stable USB power.
- Phone hotspots may change DHCP addresses after reconnecting, so check Serial Monitor again.

### Plane movement is reversed

In `main.js`, negate the matching normalized controller value. For example:

```javascript
targetRoll = -THREE.MathUtils.clamp(controls.controllerRoll / 45, -1, 1);
```

### Pitch or roll is reversed

Negate only `targetPitch` or `targetRoll` in `main.js`. Do not swap sensor axes unless the MPU6050 board is physically mounted in a different orientation.

### Plane shakes while the controller is still

- Press **CALIBRATE REMOTE** while holding the remote still.
- Increase the JavaScript dead zone from `0.025` to about `0.04` in `main.js`.
- Check for loose MPU6050 wires.

### MPU6050 values drift

Restart the ESP32 and keep it flat and completely still throughout startup gyro calibration. The MPU6050 has no magnetometer, so the project transmits yaw rate rather than absolute compass heading.

### Frame rate is low

- Close extra Chromium tabs.
- Keep Chromium hardware acceleration enabled.
- In `main.js`, change the renderer pixel-ratio cap from `1.5` to `1.0`.
- Disable shadow mapping by setting `renderer.shadowMap.enabled = false`.

### Three.js fails to load offline

Confirm `assets/three.min.js` exists and that Terminal was opened inside the `flight-simulator` directory before starting the server. Reload Chromium with `Ctrl+Shift+R`.

## Architecture for a school presentation

The project is divided into small files so each part has one clear job:

- **index.html** contains the simulator screen, HUD, start screen, and buttons.
- **style.css** controls the full-screen layout, readable panels, status colors, and responsive display.
- **websocket.js** creates one connection for each ESP32, checks incoming JSON, and reconnects automatically.
- **city.js** builds the road grid, small low-rise shops, efficient instanced trees, and building collision boxes.
- **flight.js** builds both color-coded airplanes and contains their movement and chase cameras.
- **main.js** is the game authority. It manages both remotes, split rendering, bullets, hit detection, health, scores, respawns, rematches, telemetry, and the animation loop.

The ESP32 reads the MPU6050 at 100 Hz, joins the same Wi-Fi as the Raspberry Pi, and receives an address automatically from DHCP. It sends the latest motion state about 60 times per second and sends GPIO5 press/release events immediately with a separate fire sequence number. Application-level ping/pong messages measure round-trip time once per second. The browser rejects duplicate or old sequence numbers, keeps only the newest control state, and passes it directly to the responsive arcade flight model. Three.js draws the town using instanced shops, awnings, roofs, and trees to reduce Raspberry Pi draw calls.
